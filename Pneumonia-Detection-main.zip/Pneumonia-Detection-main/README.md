# Pneumonia-Detection
Using Transfer learning to classify lungs x-ray as normal and pneumonia. And also proving transfer learning work much better than using cnn in terms of efficiency and time taken to train.
